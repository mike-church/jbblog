<?php
/**
 * Sometimes, It is good to have nothing.
 */